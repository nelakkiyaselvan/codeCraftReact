import React, { Component } from 'react';
import './css/App.css';
import { productList } from './productList';
import { productSKUs } from './productList';
// console.log(productSKUs);
import rightChevron from './img/chevron-right.png'
import backWhite from './img/back-wh.png'
//const productList = {products:[{identifier:"100002",name:"Bed lamp",image:"./img/lamp.png",type:{"label":"In","value":"Bedroom"},properties:{"skus":[{"color":"#FF4563"},{"color":"#8245E6"},{"color":"#4AC0E0"},{"color":"#1089EB"},{"color":"#C791CD"}]}},{identifier:"100003",name:"Noria AC",image:"./img/ac.png",type:{"label":"In","value":"Bedroom"},properties:{"skus":[{"color":"#FF4563"},{"color":"#8245E6"},{"color":"#4AC0E0"},{"color":"#1089EB"},{"color":"#C791CD"}]}},{identifier:"100004",name:"Door Lock",image:"./img/lock.png",type:{"label":"In","value":"Home office"},properties:{"skus":[{"color":"#FF4563"},{"color":"#8245E6"},{"color":"#4AC0E0"},{"color":"#1089EB"},{"color":"#C791CD"}]}},{identifier:"100007",name:"LG TV",image:"./img/tv.png",type:{"label":"In","value":"Living room"},properties:{"skus":[{"color":"#FF4563"},{"color":"#8245E6"},{"color":"#4AC0E0"},{"color":"#1089EB"},{"color":"#C791CD"}]}},{identifier:"100008",name:"Sony TV",image:"./img/tv.png",properties:{"skus":[{"color":"#8245E6"},{"color":"#FF4563"},{"color":"#1089EB"},{"color":"#4AC0E0"},{"color":"#C791CD"}]}},{identifier:"100012",name:"Locker",image:"",type:{"label":"In","value":"Bedroom"},properties:{"skus":[{"color":"#1089EB"},{"color":"#FF4563"},{"color":"#4AC0E0"},{"color":"#8245E6"},{"color":"#C791CD"}]}},{identifier:"100010",name:"Thermostat",image:"./img/thermostat.png",type:{"label":"In","value":"Bedroom"},properties:{"skus":[{"color":"#8245E6"},{"color":"#4AC0E0"},{"color":"#C791CD"},{"color":"#FF4563"},{"color":"#1089EB"}]}}]};

class App extends Component {
  constructor(props) {
    super(props);
    this.state = { pdtListDom: [], productList: productList, productSKUs: productSKUs, selectedPdt: null}
  }
//   getProductList = () => {
//     fetch("https://d167y3o4ydtmfg.cloudfront.net/541/studio/assets/v1565363154118_293994083/productJSON.json")
//         .then(res => res.json())
//         .then(
//             (result) => {
//                 this.setState({
//                     isLoaded: true,
//                     response: result,
//                     responseLength: result.length,
//                     success: true
//                 });
//             },
//             (error) => {
//                 if(productList && Object.keys(productList).length) {
//                   this.setState({
//                       isLoaded: true,
//                       productList: productList,
//                       success: true
//                   });
//                 }
//             }
//         )
//   }


  render() {
    return (
        <div class="wrapper">
            <div class="leftWrapper">
                <PdtList this={this} />
            </div>
            <div class="rightWrapper">
                {this.state.selectedPdt ? <PdtDetails this={this} /> : ""}
            </div>
        </div>
    );
  }
}


class PdtList extends Component {

  renderPdtDetail = (e) => {
    let target = e.currentTarget;
    if(!target.classList.contains('active')){
        // let prevEle = $('.pdtListDetail.active')
        // $('.pdtListCont').append(prevEle);
        // $this.insertAfter($('.pdtListDetail')[0]);
        let prevEle = target.parentElement.getElementsByClassName('active');
        prevEle.length ? prevEle[0].classList.remove('active') : '';
        target.classList.add('active');
        document.getElementById('backBtn').style.display = "block";
        document.getElementById('indicator').style.display = "block";
        // let productTitle = rghtPanel.getElementsByClassName('productTitle')[0];
        let pdtTitle = target.getElementsByClassName('pdtTitle')[0];
        pdtTitle = pdtTitle ? pdtTitle.textContent : "";
        this.props.this.setState({selectedPdt : target.getAttribute('identifier'), productTitle : pdtTitle});
        // productTitle ? productTitle.textContent = (pdtTitle ? pdtTitle.textContent : "") : "";
    }
  }

  constructPdtList = (data) => {
    if (data.name && data.image && data.identifier) {
        return (
                <div class="pdtListDetail" identifier={data.identifier} onClick={this.renderPdtDetail.bind(this)}>
                    <div class="pdtImg">
                        <img src={require(data.image)} />
                    </div>
                    <div class="pdtDetail">
                        <ul class="pdtDetailList">
                            <li class="pdtTitle">{data.name}</li>
                            {data.type ? <li class="pdtType"><span class="">{data.type.label} </span>{data.type.value}</li> : ''}
                        </ul>
                    </div>
                </div>
        );
    }
  }

  renderPdtList = (props) => {
    if(Object.keys(props.state.productList).length) {
        if (!props.state.pdtListDom.length) {
            var pdtList = props.state.productList;
            if(pdtList.products && pdtList.products.length) {
                var pdtList = pdtList.products.map(this.constructPdtList);
                props.setState({pdtListDom : pdtList})
                // let parentEle = $('.pdtListCont');
                // parentEle.append(pdtListDom);
            // let x = $('.pdtListDetail:last-child').clone().addClass('duplicate');
                // parentEle.prepend(x);
            }
        } else {
            return (props.state.pdtListDom);
        }
    } else {
      return (
        <div class="noDataFnd">No skus found...</div>
      )
    }
  }

  render() {
    return(
      <div class="leftPanel panels">
      <div id="indicator"><img src={rightChevron} /></div>
      <div class="pdtListWrapper">
          <div id="backBtn">
            <img src={backWhite} />
          </div>
          <div class="pdtListCont">
            {this.renderPdtList(this.props.this)}
          </div>
      </div>
    </div>
    )
  }
}

class PdtDetails extends Component {

    toggleDetail = (e) => {
        let pdtDetailEle = document.getElementById('deviceDetWrap');
        if(e.currentTarget.checked) {
            pdtDetailEle.style.display = "block";
            // this.renderPdtDetails();
        } else {
            pdtDetailEle.style.display = "none";
        }
    }

    renderPdtDetails = () => {
        let selectedPdt = document.getElementsByClassName('pdtListDetail active')[0];
        let pdtId = selectedPdt ? selectedPdt.getAttribute('identifier') : '';
        if(pdtId) {
            var skuDom = this.constructSkus(pdtId);
            let rghtPanel = document.getElementById('rightPanel');
            rghtPanel ? rghtPanel.style.display = "block" : '';
            return skuDom;
        }
    }

    skuClick = (e) => {
        let curSku = e.currentTarget;
        let parentEle = curSku.parentElement;
        // resetMode();
        if(curSku.checked && !parentEle.classList.contains('.active')) {
            let prevSku = document.getElementsByClassName('skuClrCont active')[0];
            if(prevSku) {
                prevSku.querySelector('input').checked = false;
                prevSku.classList.remove('active');
            }
            curSku.closest('.skuClrCont').classList.add('active');
            // $('.featureCont , .quickDemoCont').removeClass('disabled');
            document.querySelectorAll('.featureCont , .quickDemoCont').forEach(ele => {
                if(ele)
                    ele.classList.remove('disabled');
            });
        } else {
            
            parentEle.classList.add('active');
        }
    }

    resetMode = () => {
        document.querySelectorAll('.featureCont , .quickDemoCont').forEach(ele => {
            if(ele)
                ele.classList.add('disabled');
        });
        let selectedMode = document.getElementsByClassName('modes active')[0];
        selectedMode ? selectedMode.classList.remove('active') : '';
        // $('.swipeBall , .leftScroller').removeAttr('style');
        // $('.volume').text(0);
    }
    
    selectMode = (e) => {
        let curEle = e.currentTarget;
        if(!curEle.classList.contains('active')){
            let prevEle = document.getElementsByClassName('modes active')[0];
            prevEle ? prevEle.classList.remove('active') : '';
            curEle.classList.add('active');
            let demoEle =  document.getElementsByClassName('quickDemoCont')[0];
            let volume = curEle.getElementsByClassName('modeVolume')[0].textContent.trim();
            let diskMov = volume.split('%').join('');
            let degree = (50 > diskMov) ? (360 - 25) : ((50 == diskMov) ? 360 : (360 + 78));
    
            // let viewPort = demoEle.offset().top - $('body').height() + demoEle.outerHeight();
            // $('body').animate({scrollTop: viewPort},100);
    
            document.getElementById("swipeBall").style.transform = 'rotate(' + degree + 'deg)';
            document.querySelector(".scrollerWrap .leftScroller").style.width = volume;
            document.getElementById('volume').textContent = diskMov;
        }
    }

    constructSkus = (id) => {
        let pdtSkus = productSKUs.length ? productSKUs : [];
        var curEle = pdtSkus.filter((ele) => ele.identifier == id ).pop();

        if(curEle && curEle.skus && curEle.skus.length) {
            let skus = curEle.skus;
            var skuCont = skus.map(data => {
                return (
                    <div class="skuClrCont">
                        <label class="colorSku">
                        <input type="checkbox" onClick={this.skuClick} />
                        <span class="selected" style={{backgroundColor: data.color}}></span>
                        </label>
                    </div>
                    );
            });

            return (
                skuCont
            );
        } else {
            return (
                <div class="noDataFnd">No skus found...</div>
            )
        }
    }

    render() {
    // this.renderPdtDetails();
    const skuDom = this.renderPdtDetails();
        return(
            <div id="rightPanel" class="panels">
                <div class="rgtPanelWrap">
                    <div class="panelTitle">Devices</div>
                    <div class="pdtTitleCont">
                        <h3 class="productTitle">{this.props.this.state.productTitle}</h3>
                        <div class="toggleCont">
                            <label class="toggleBtn">
                                <input id="togBtn" type="checkbox" defaultChecked onClick={this.toggleDetail} />
                                <span class="toggleDot"></span>
                            </label>
                        </div>
                    </div>
                    <div id="deviceDetWrap">
                        <div class="deviceSkuCont">
                            <div class="skuTitle">
                                <span class="deviceSkuTitle">Shades</span>
                                <div class="titleBorder"></div>
                            </div>
                            <div class="deviceSkus">{skuDom}</div>
                        </div>
                        <div class="featureCont disabled">
                            <div class="skuTitle">
                                <span class="deviceSkuTitle">Mode</span>
                                <div class="titleBorder"></div>
                            </div>
                            <div class="modeList">
                                <div class="modes mornMode" onClick={this.selectMode}>
                                    <div class="modeDetail">
                                        <div class="modeImg" id="mornModeImg"></div>
                                        <span class="modeTitle">Morning</span>
                                    </div>
                                    <div class="modeDetail">
                                        <div class="modeVolume modeTitle">50%</div>
                                        <div class="modeAvail modeImg"></div>
                                    </div>
                                </div>
                                <div class="modes dayMode">
                                    <div class="modeDetail">
                                        <div class="modeImg" id="dayModeImg"></div>
                                        <span class="modeTitle">Day</span>
                                    </div>
                                    <div class="modeDetail">
                                        <div class="modeVolume modeTitle">30%</div>
                                        <div class="modeAvail modeImg"></div>
                                    </div>
                                </div>
                                <div class="modes nightMode">
                                    <div class="modeDetail">
                                        <div class="modeImg" id="nightModeImg"></div>
                                        <span class="modeTitle">Night</span>
                                    </div>
                                    <div class="modeDetail">
                                        <div class="modeVolume modeTitle">100%</div>
                                        <div class="modeAvail modeImg"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="quickDemoCont disabled">
                            <div class="skuTitle">
                                <span class="deviceSkuTitle">Intensity</span>
                                <div class="titleBorder"></div>
                            </div>
                            <div class="scrollerWrap">
                                <div class="swipeBall"></div>
                                <div class="leftScroller">
                                    <div class="scrollerCont">
                                    <div class="scroller"></div>
                                    </div>
                                </div>
                                <div class="rightScroller">
                                    <div class="scrollerCont">
                                        <div class="scroller"></div>
                                    </div>
                                </div>
                                <span id="volume">0</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

export default App;
